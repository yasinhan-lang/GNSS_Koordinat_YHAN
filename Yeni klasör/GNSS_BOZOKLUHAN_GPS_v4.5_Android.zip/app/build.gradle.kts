plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yhan.gnsskoordinat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yhan.gnsskoordinat"
        minSdk = 24
        targetSdk = 34
        versionCode = 22
        versionName = "4.5"
    }

    // Sabit imza: her derlenen APK bir öncekinin üzerine kurulabilir (veriler korunur).
    signingConfigs {
        create("yhan") {
            storeFile = file("yhan.keystore")
            storePassword = "yhan2026gnss"
            keyAlias = "yhan"
            keyPassword = "yhan2026gnss"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("yhan")
        }
        debug {
            signingConfig = signingConfigs.getByName("yhan")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
